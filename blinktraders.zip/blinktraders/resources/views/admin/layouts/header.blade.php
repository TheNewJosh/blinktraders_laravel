<div class="d-flex justify-content-between mt-4">
    <div class="ml-5"><h2 class="force-color-black"><span class="mr-5" id="toggle-bar-menu"><i class="fas fa-bars"></i></span><?= $page_title ?></h2></div>
<!--
    <div class="nav-item nav-item-border-b dropdown">
        <a class="dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="dashnav-link-text"><i class="far fa-user-circle force-color-black"></i></span>
        </a>
        <div class="dropdown-menu dash-head-drop" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item force-color-pale-white" href="blog.php">Account</a>
          <a class="dropdown-item force-color-red" href="#">Logout</a>
        </div>
      </div>
-->
</div>